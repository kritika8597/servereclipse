package com.example.kp.speechtotext;

/**
 * Created by KP on 7/3/2018.
 */

class VolleyRequests {
    public VolleyRequests(MainActivity mainActivity) {
    }
}
