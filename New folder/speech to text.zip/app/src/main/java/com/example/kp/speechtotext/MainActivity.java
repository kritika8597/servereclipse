package com.example.kp.speechtotext;

import android.app.VoiceInteractor;
import android.content.Context;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.lang.ref.ReferenceQueue;
import java.util.ArrayList;
import java.util.Locale;

import static android.R.attr.contextClickable;
import static android.R.attr.contextUri;
import static android.R.attr.tag;

public class MainActivity extends AppCompatActivity {

    private TextView txvResult;
    private com.android.volley.toolbox.Volley volley;
    private JSONObject jsonRequest;
    @Override
    protected void onCreate(Bundle savedInstanceState)

    // responsible to create an activity
    //whenever orientation or terminating by os take place it is saved by savedInstanceState, After Orientation changed then onCreate(Bundle savedInstanceState) will call and recreate the activity and load all data from savedInstanceStat
    {
        super.onCreate(savedInstanceState);
        //However, you must include this super call in your method, because if you don't then the onCreate() code in Activity is never run, and your app will run into all sorts of problem like having no Context assigned to the Activity
        setContentView(R.layout.activity_main);
        //R.layout.* references any layout resource you have created, usually in /res/layout. So if you created an activity layout called activity_main.xml, you can then use the reference in R.layout.activity_main to access it.
        txvResult = (TextView) findViewById(R.id.txvResult);

    }

    public void getSpeechInput(View view) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        //

        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, Locale.getDefault());
        //locale.getDefault -- default language of mobile
//The Google Voice API is performed in the network, so if you’re using the Google speech rec, it will only function when your network is activated.Speech recognition is achieved using the android.speech.RecognizerIntent. class. When we want to invoke the speech recogniser we simply fire a RecognizerIntent
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);

        } else {
            Toast.makeText(this, "your device dont support speech input", Toast.LENGTH_SHORT).show();
            //A toast provides simple feedback about an operation in a small popup. It only fills the amount of space required for the message and the current activity remains visible and interactive. Toasts automatically disappear after a timeout.
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//When the user is done with the subsequent activity and returns, the system calls your activity's (onActivityResult)method. This method includes three arguments:
        //The request code you passed to requestCode
        //A result code specified by the second activity. This is either resultcode if the operation was successful or result_cancelled if the user backed out or the operation failed for some reason.
        //An Intent that carries the result data
        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    txvResult.setText(result.get(0));
                }
                break;
        }
       // String URL="http://192.168.43.202 :8080/webapp/";


        //Context context;
        //VolleyRequests volleyrequests = new VolleyRequests (this);
        //RequestQueue requestQueue=Volley.newRequestQueue(context);
        //volleyrequests = new VolleyRequests(this);
        //JSONObject listener;
        //JsonObjectRequest objectRequest=new JsonObjectRequest(
          //      Request.Method.GET,
            //    URL,
              // listener: txvResult,

               // new Response.Listener<JSONObject>() {
                 //   @Override
                   // public void onResponse(Object response) {

                    }
                }
            //    new Response.Listener<JSONObject>()   (
        //public void onResponse(JSONObject response)    (
              //  Log.e(tag"Rest Response",)
    //}
//}
//new Response.ErrorListener(){
//@Override
//public void onErrorResponse(VolleyError error)
  //      }
    //    )
      //  );


  //      }
